const fs = require('fs');
const { redisClient } = require('../config/redis-config');

// Task function that logs task completion
async function task(user_id) {
  const logEntry = `${user_id}-task completed at-${Date.now()}\n`;
  fs.appendFileSync('./logs/tasks.log', logEntry);
  console.log(logEntry.trim());
}

// Rate limiting and task queueing
async function addTaskToQueue(user_id) {
  const currentTime = Date.now();
  
  // Check rate limit (1 task per second, 20 tasks per minute per user)
  const key = `rate_limit:${user_id}`;
  const taskCount = await redisClient.incr(key);
  if (taskCount === 1) {
    // Set expiry to 60 seconds for the rate limit
    await redisClient.expire(key, 60);
  }

  if (taskCount > 20) {
    console.log(`User ${user_id} has exceeded the rate limit`);
    return false;
  }
  
  // Add task to queue with delay based on rate limit
  setTimeout(async () => {
    await task(user_id);
  }, 1000); // 1 task per second

  return true;
}

module.exports = { addTaskToQueue };
