# Node.js API with Task Queue and Rate Limiting

## Requirements
- Node.js v20.x or above
- Redis installed and running

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/Adarshsingh56/node-api-cluster.git
   cd node-api-cluster
