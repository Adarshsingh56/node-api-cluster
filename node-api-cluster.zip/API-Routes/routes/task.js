const express = require('express');
const { addTaskToQueue } = require('../controllers/task-queue');
const router = express.Router();

router.post('/', async (req, res) => {
  const { user_id } = req.body;

  if (!user_id) {
    return res.status(400).json({ error: 'user_id is required' });
  }

  const added = await addTaskToQueue(user_id);
  if (!added) {
    return res.status(429).json({ error: 'Rate limit exceeded' });
  }

  return res.status(202).json({ message: 'Task added to queue' });
});

module.exports = router;
