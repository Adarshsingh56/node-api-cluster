const express = require('express');
const bodyParser = require('body-parser');
const taskRoutes = require('./routes/task');
const { redisClient } = require('./config/redis-config');

// Initialize the server
const app = express();
app.use(bodyParser.json());

// Use task routes
app.use('/task', taskRoutes);

// Start the server on port 3000
app.listen(3000, () => {
  console.log('Node.js API running on port 3000');
});
